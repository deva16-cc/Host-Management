#!/usr/bin/env bash
set -euo pipefail
docker compose stop
docker compose ps
